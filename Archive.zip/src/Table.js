import React, {Component} from 'react';
import Guest from './Guest';
import { Droppable } from 'react-beautiful-dnd';
//!!Organizing temp layout
import styled from 'styled-components'

//!!Organizing temp layout
const Container = styled.div `
  margin: 8px;
  border: 1px solid lightgrey;
  border-radius: 2px;
  width: auto;
  display: flex;
  flex-direction: row;
  flex: 1;
  `;

  const Wrapper = styled.div`
  margin: 8px;
  border: 1px solid lightgrey;
  border-radius: 2px;
  width: auto;
  min-height: 220px;
  display: flex;
  flex-direction: column;
  flex: 1;
  `;

  const GuestLook = styled.div`
  margin: 8px;
  border: 1px solid lightgrey;
  border-radius: 2px;
  width: auto;
  display: flex;
  flex-direction: column;
  flex: 1;
  `;

class Table extends Component {

    // Add a guest to table
    addGuest = () => {
        // Add code here
    }

    // Remove a guest from table
    removeGuest = () => {
        // Add code here
    }

    render() {
        const displayTable = () => {
            if(this.props.tables.length>0) {
                return this.props.tables.map((table, index) =>         
               <Wrapper key = {index}><h3>Table {table.tableName}</h3></Wrapper>)
                }
        }
                     

        const guestList = ( 
            <div>
                {/* {Give hard coded ID} */}
                <h3>GuestList</h3>
                <h4>Size {this.props.tables[0].length}</h4>
            </div>
        )

        const guests = this
            .props
            .tables[0].guests
            .map((guest, index) => <GuestLook key={index} ><Guest guest={guest}/></GuestLook>)

        return (
            <div>
                <Container>
                    <Wrapper>
                        {guestList}
                        {guests}
                    </Wrapper>
                    {displayTable()}
                </Container>

            </div>
        );
    }
}

export default Table;